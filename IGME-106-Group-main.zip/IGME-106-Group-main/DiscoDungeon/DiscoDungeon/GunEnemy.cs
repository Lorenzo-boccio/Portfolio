﻿// Dylan Daccarett
// 4/9/2022
// Handling ranged-enemy movement and behavior.
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace DiscoDungeon
{
    class GunEnemy : Enemy
    {
        private Rectangle lineOfSight;
        private List<Projectile> shotBullets = new List<Projectile>();
        private Texture2D projectileTexture;
        private bool canAttack;
        private float cooldownTime;
        public Rectangle LineOfSight
        {
            get { return lineOfSight; }
        }

        public bool CanAttack
        {
            get { return canAttack; }
        }

        public float CooldownTime
        {
            get { return cooldownTime; }
            set { cooldownTime = value; }
        }

        public List<Projectile> ShotBullets
        {
            get { return shotBullets; }
        }
        public GunEnemy(Texture2D texture, Texture2D projectileTexture, int x, int y, float speed, int damage) : base(texture, x, y, speed, damage)
        {
            this.projectileTexture = projectileTexture;
            lineOfSight = new Rectangle(location.X + texture.Width, location.Y, 1000, texture.Height);
            floorCheck = new Rectangle(location.X + texture.Width + 10, location.Y + texture.Height, 10, 10);
            entityVelocity = Vector2.Zero;
            jumpVelocity = new Vector2(0, -10.0f);
            gravity = new Vector2(0, 0.5f);
            FacingRight = true;
            canAttack = false;
        }
                    
        public override void Attack(Player player, int damage)
        {
            if(lineOfSight.Intersects(player.LocationRect) && canAttack)
            {
                shotBullets.Add(new Projectile(projectileTexture, location.X, location.Y + LocationRect.Height / 2, 5f, damage, FacingRight));
                canAttack = false;
                cooldownTime = 0;
            }
            for(int i = 0; i < shotBullets.Count; i++)
            {
                if (shotBullets[i].PosX > 1890 || shotBullets[i].PosX < 30 || shotBullets[i].Active == false)
                {
                    shotBullets.RemoveAt(i);
                    i--;
                }
            }
        }

        public override void MoveEnemy()
        {
            base.MoveEnemy();
            lineOfSight.Y = location.Y;
            if(FacingRight)
            {
                lineOfSight.X = location.X;
            }
            else
            {
                lineOfSight.X = location.X - 1000;
            }
            lineOfSight.Y = location.Y;

            
            if(cooldownTime > 2500)
            {
                canAttack = true;
                cooldownTime = 0;
            }
        }
        Random rng = new Random();
        public override void Draw(SpriteBatch sb)
        {

            base.Draw(sb);
            foreach(Projectile projectile in shotBullets)
            {
                Color color = new Color(rng.Next(0, 255), rng.Next(0, 100), rng.Next(0, 255), 255);
                sb.Draw(projectileTexture, projectile.LocationRect, color);

            }
        }
    }
}
