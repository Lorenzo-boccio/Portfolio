﻿// Lorenzo Boccio
// 3/28/2022
// Holds all information about rooms as well as draw method

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace DiscoDungeon
{
    public class Room
    {
        Texture2D backgorundTexture;
        Texture2D texturePlatform;
        Texture2D textureWall;

        public List<Rectangle> platforms = new List<Rectangle>();
        Rectangle wallLeft;
        Rectangle wallRight;
        List<Entity> enemySpawn = new List<Entity>();
        Point playerSpawn;
        public Item item;

        // property for enemy spawns for loading the set will add the value to the spawns
        public List<Entity> EnemySpawns
        {
            get { return enemySpawn; }
        }

        // get for platform list
        public List<Rectangle> Platforms
        {
            get { return platforms; }
        }

        // indexer for easy access to platforms
        public Rectangle this[int index]
        {
            get { return platforms[index]; }
            set { platforms[index] = value; }
        }

        // Property to get and set player's spawn 
        public Point PlayerSpawn
        {
            get { return playerSpawn; }
            set { playerSpawn = value; }
        }

        /// <summary>
        /// creates new room object and should make walls and floor
        /// </summary>
        public Room(Texture2D bg, Texture2D platform, Texture2D wall, Item item)
        {
            this.backgorundTexture = bg;
            this.texturePlatform = platform;
            this.textureWall = wall;
            this.item = item;

            wallLeft = new Rectangle(0, 0, 30, Game1.screenHeight);
            wallRight = new Rectangle(Game1.screenWidth - 30, 0, 30, Game1.screenHeight);
            platforms.Add(wallLeft);
            platforms.Add(wallRight);

            //Floor
            //platforms.Add(new Rectangle(0, Game1.screenHeight - 30, Game1.screenWidth - 80, 30));
        }

        /// <summary>
        /// defualt room constructor
        /// </summary>
        public Room()
        {
            wallLeft = new Rectangle(0, 0, 30, Game1.screenHeight);
            wallRight = new Rectangle(Game1.screenWidth - 30, 0, 30, Game1.screenHeight);
            platforms.Add(wallLeft);
            platforms.Add(wallRight);
            this.item = null;

            // floor of level can be removed later
            //platforms.Add(new Rectangle(0, Game1.screenHeight - 30, Game1.screenWidth, 30));

            textureWall = Game1.wallTexture;
            texturePlatform = Game1.platformTexture;
            backgorundTexture = Game1.bgTexture;
        }


        /// <summary>
        /// draws all the parts of the background and walls as well as platforms
        /// </summary>
        /// <param name="sb"></param>
        public void Draw(SpriteBatch sb)
        {
            sb.Draw(this.backgorundTexture,
               new Rectangle(0, 0, Game1.screenWidth, Game1.screenHeight),
                Color.Gray);

            sb.Draw(textureWall, wallLeft, Color.White);
            sb.Draw(textureWall, wallRight, Color.White);

            foreach (Rectangle rect in platforms)
            {
                sb.Draw(texturePlatform, rect, Color.White);
            }
        }
    }
}
