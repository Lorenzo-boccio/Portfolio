﻿// Dylan Daccarett
// 4/9/2022
// Handling projectiles.
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace DiscoDungeon
{
    class Projectile : Entity
    {
        private bool direction;
        public bool Direction
        {
            get { return direction; }
        }
        public Projectile(Texture2D texture, int x, int y, float speed, int damage, bool direction) : base(texture, x, y, speed, damage)
        {
            this.Active = true;
            this.direction = direction;
        }

        public void Move(List<Rectangle> rects)
        {
            if(direction)
            {
                position.X += Speed;
            }
            else
            {
                position.X -= Speed;
            }
            foreach(Rectangle rectangle in rects)
            {
                if (this.LocationRect.Intersects(rectangle))
                {
                    this.Active = false;
                }
            }
            UpdateLocation();
        }
    }
}
