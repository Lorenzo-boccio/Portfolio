﻿//4/8/2022

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace DiscoDungeon
{
    static class RoomManager
    {
        static List<Room> rooms = new List<Room>();
        public static List<Room> recyclingBin = new List<Room>();

        /// <summary>
        /// Loads rooms in from a file
        /// </summary>
        static public void Load(string fileName)
        {
            // Create room
            Room room = new Room();

            StreamReader input = new StreamReader(fileName);

            string line = null;

            while ((line = input.ReadLine()) != null)
            {
                // Get information
                string[] tileInfo = line.Split('|');

                // Get set data based on tile type
                switch (tileInfo[0])
                {
                    // Middle Platform
                    case "Platform_Mid":
                        // Add platform at tile's x and y coordinates
                        room.Platforms.Add(new Rectangle(int.Parse(tileInfo[1]), int.Parse(tileInfo[2]), 30, 30));
                        break;

                    // Left Platform
                    case "Platform_Left":
                        // Add platform at tile's x and y coordinates
                        room.Platforms.Add(new Rectangle(int.Parse(tileInfo[1]), int.Parse(tileInfo[2]), 30, 30));
                        break;

                    // Right Platform
                    case "Platform_Right":
                        // Add platform at tile's x and y coordinates
                        room.Platforms.Add(new Rectangle(int.Parse(tileInfo[1]), int.Parse(tileInfo[2]), 30, 30));
                        break;

                    // Player Spawn
                    case "Player_Spawn":
                        // Set player spawn to x and y points
                        room.PlayerSpawn = new Point(int.Parse(tileInfo[1]), int.Parse(tileInfo[2]) - 40);
                        break;

                    // Leg Enemy
                    case "Leg_Enemy":
                        room.EnemySpawns.Add(new Enemy(Game1.enemyTexture, int.Parse(tileInfo[1]), int.Parse(tileInfo[2]) - 50, 4f, 0));
                        break;

                    // Arm Enemy
                    case "Arm_Enemy":
                        room.EnemySpawns.Add(new FloatingEnemy(Game1.enemyTexture, int.Parse(tileInfo[1]), int.Parse(tileInfo[2]), 2f, 0));
                        break;

                    // Gun Enemy
                    case "Gun_Enemy":
                        room.EnemySpawns.Add(new GunEnemy(Game1.gunEnemyTexture, Game1.projectileTexture, int.Parse(tileInfo[1]), int.Parse(tileInfo[2]) - 50, 3f, 0));
                        break;

                    // Item
                    case "Item_Spawn":
                        room.item = new Item("item", Game1.itemTexture, 0, 10);
                        room.item.X = int.Parse(tileInfo[1]);
                        room.item.Y = int.Parse(tileInfo[2]);
                        break;
                }
            }

            input.Close();

            // Add room to list
            rooms.Add(room);
        }

        /// <summary>
        /// Returns a room for Game1 to use
        /// </summary>
        /// <returns></returns>
        static public Room GetRoom()
        {
            Random rng = new Random();
            Room temp = rooms[rng.Next(0, rooms.Count)];
            rooms.Remove(temp);
            recyclingBin.Add(temp);

            return temp;
        }

        /// <summary>
        /// Adds used rooms back into list
        /// </summary>
        static public void RecycleRooms()
        {
            rooms.AddRange(recyclingBin);
            recyclingBin.Clear();
        }
    }
}
