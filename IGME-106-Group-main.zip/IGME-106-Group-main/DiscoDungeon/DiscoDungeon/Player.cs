﻿//Deegan Melchiondo
//3/16/2022
//Handle all things that deal with the player specifically

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DiscoDungeon
{
    class Player : Entity
    {
        private int health;
        private KeyboardState prevState;

        /// <summary>
        /// Get or set the player's current health
        /// </summary>
        public int Health { get { return health; } set { health = value; } }

        /// <summary>
        /// Creates a player, which is a child of the Entity class
        /// </summary>
        /// <param name="texture">passed to Entity</param>
        /// <param name="speed">passed to Entity</param>
        /// <param name="damage">passed to Entity</param>
        /// <param name="health">Starting health for the player</param>
        public Player(Texture2D texture, int x, int y, float speed, int damage, int health) : base(texture, x, y, speed, damage)
        {
            this.health = health;
            entityVelocity = Vector2.Zero;
            jumpVelocity = new Vector2(0, -12.0f);
            gravity = new Vector2(0, 0.5f);
        }

        /// <summary>
        /// Handles all movement the player can make
        /// </summary>
        /// <param name="key"></param>
        public void Move()
        {
            KeyboardState keyState = Keyboard.GetState();

            //left
            if (keyState.IsKeyDown(Keys.A) && !(BounceRight || BounceLeft))
            {
                position.X -= Speed;
            }
            //right
            if (keyState.IsKeyDown(Keys.D) && !(BounceRight || BounceLeft))
            {
                position.X += Speed;
            }
            //jump
            if (keyState.IsKeyDown(Keys.Space) && !prevState.Equals(keyState) && OnGround && entityVelocity.Y >= 0 && entityVelocity.Y <= 1)
            {
                entityVelocity.Y = jumpVelocity.Y;
                OnGround = false;
            }

            ApplyGravity();
            UpdateLocation();

            prevState = keyState;
        }

        /// <summary>
        /// Modifies the player's stats based on the item they picked up
        /// </summary>
        public void ItemPickup(Item item)
        {
            Health += item.HealthMod;
            Speed += item.SpeedMod;
        }

        /// <summary>
        /// Would handle how attacking would work, but this may not be used. Leave empty for now.
        /// </summary>
        public void Attack (Keys key)
        {
            throw new NotImplementedException();
        }
    }
}
