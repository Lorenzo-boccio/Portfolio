﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;

namespace DiscoDungeon
{
    public enum GameState
    {
        Menu,
        Gameplay,
        Win,
        Lose,
    }

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Player p;
        private Enemy e;
        private FloatingEnemy f;
        private GunEnemy g;
        public static Texture2D wallTexture;
        private Texture2D playerTexture;
        public static Texture2D enemyTexture;
        public static Texture2D gunEnemyTexture;
        public static Texture2D projectileTexture;
        public static Texture2D platformTexture;
        public static Texture2D itemTexture;
        public static Texture2D bgTexture;
        private SpriteFont debugText;
        private SpriteFont titleText; // FOR TEMPORARY TITLE SCREEN, CAN DELETE LATER
        private int levels;
        private double deathCooldown;

        private List<Rectangle> obstacleRects;
        private Room currRoom;
        private Item currItem;
        public static int screenWidth;
        public static int screenHeight;
        private List<Entity> roomEnemies;
        private List<Item> items;
        private Random rng;

        private Color menuColor1;
        private Color menuColor2;
        private Color menuColor3;
        private Color menuColor4;
        private double menuTimer;

        private GameState gameState;
        private bool godmode = false;
        private KeyboardState prevKBS;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 1080;
            _graphics.ApplyChanges();
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            obstacleRects = new List<Rectangle>();

            _graphics.PreferredBackBufferWidth = GraphicsDevice.DisplayMode.Width;
            _graphics.PreferredBackBufferHeight = GraphicsDevice.DisplayMode.Height;
            _graphics.IsFullScreen = false;
            _graphics.ApplyChanges();

            screenWidth = _graphics.PreferredBackBufferWidth;
            screenHeight = _graphics.PreferredBackBufferHeight;


            gameState = GameState.Menu;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            wallTexture = Content.Load<Texture2D>("pixel");
            playerTexture = Content.Load<Texture2D>("discoChar");
            enemyTexture = Content.Load<Texture2D>("BALLLEG");
            gunEnemyTexture = Content.Load<Texture2D>("GUNBASS");
            projectileTexture = Content.Load<Texture2D>("PROJECTILE");
            platformTexture = Content.Load<Texture2D>("DiscoTile");
            itemTexture = Content.Load<Texture2D>("ItemIcon");
            bgTexture = Content.Load<Texture2D>("pxArt");
            debugText = Content.Load<SpriteFont>("Arial12");
            titleText = Content.Load<SpriteFont>("TitleFont");

            p = new Player(playerTexture, 300, 100, 4f, 0, 5);
            e = new Enemy(enemyTexture, 300, 100, 4f, 0);
            f = new FloatingEnemy(enemyTexture, 500, 100, 2f, 0);
            g = new GunEnemy(enemyTexture, projectileTexture, 300, 100, 3f, 0);

            menuColor1 = new Color(4, 177, 119);
            menuColor2 = new Color(144, 39, 136);
            menuColor3 = new Color(1, 126, 236);
            menuColor4 = new Color(126, 114, 102);

            roomEnemies = new List<Entity>();
            items = new List<Item>();
            rng = new Random();

            RoomManager.Load("Content/DDtestLevel1.level");
            RoomManager.Load("Content/DDtestLevel2.level");
            RoomManager.Load("Content/VertSnake.level");
            RoomManager.Load("Content/thedylanfiles.level");
            // RoomManager.Load("Content/lorzenos.level");
            RoomManager.Load("Content/ItemRoom.level");
            RoomManager.Load("Content/DoubleSquares.level");
            RoomManager.Load("Content/GunTower.level");
            RoomManager.Load("Content/hell.level");
            RoomManager.Load("Content/NamPipe.level");
            currRoom = RoomManager.GetRoom();
            RoomManager.recyclingBin.Clear();
            p.PosX = currRoom.PlayerSpawn.X;
            p.PosY = currRoom.PlayerSpawn.Y;

            for (int i = 0; i < currRoom.EnemySpawns.Count; i++)
            {
                roomEnemies.Add(currRoom.EnemySpawns[i]);
            }
            //e.X = currRoom.EnemySpawns[0].X;
            //e.Y = currRoom.EnemySpawns[0].Y;
            //e.PosX = currRoom.EnemySpawns[0].X;
            //e.PosY = currRoom.EnemySpawns[0].Y;

            foreach (Rectangle rect in currRoom.Platforms)
            {
                obstacleRects.Add(rect);
            }

            //if (currRoom.Item != null)
        }

        protected void ScreenBounds()
        {
            //Player goes to the top of the screen and completes the level
            if (p.LocationRect.Y < 0)
            {
                NextLevel();
            }

            //Player goes to the bottom of the screen, loses health, and resets at the starting platform
            if (p.LocationRect.Y > _graphics.PreferredBackBufferHeight)
            {
                p.PosX = currRoom.PlayerSpawn.X;
                p.PosY = currRoom.PlayerSpawn.Y;

                p.Health--;
            }
        }

        /// <summary>
        /// Fills the list with items
        /// </summary>
        protected void itemFill()
        {
            items.Clear();

            //Enter items here
            Item temp = new Item("\"Stayin\' Alive\"", itemTexture, 3, 0);
            items.Add(temp);
            temp = new Item("\"Love Train\"", itemTexture, 0, 2);
            items.Add(temp);
        }

        /// <summary>
        /// Generates the next level
        /// </summary>
        protected void NextLevel()
        {
            //Uncomment if level list crashes
            //if (gameState == GameState.Win)
            //{
            //    return;
            //}
            roomEnemies.Clear();
            currRoom = RoomManager.GetRoom();
            obstacleRects = new List<Rectangle>();
            p.PosX = currRoom.PlayerSpawn.X;
            p.PosY = currRoom.PlayerSpawn.Y;
            if(p.Health < 5)
            {
                p.Health = 5;
            }
            //e.X = currRoom.EnemySpawns[0].X;
            //e.Y = currRoom.EnemySpawns[0].Y;
            //e.PosX = currRoom.EnemySpawns[0].X;
            //e.PosY = currRoom.EnemySpawns[0].Y;

            currItem = null;

            //Sets item for the room
            if (currRoom.item != null)
            {
                currItem = items[rng.Next(items.Count)];
                currItem.Active = true;
                currItem.X = currRoom.item.X;
                currItem.Y = currRoom.item.Y;
            }

            foreach (Rectangle rect in currRoom.Platforms)
            {
                obstacleRects.Add(rect);
            }
            for (int i = 0; i < currRoom.EnemySpawns.Count; i++)
            {
                roomEnemies.Add(currRoom.EnemySpawns[i]);
            }


            levels++;
        }

        protected override void Update(GameTime gameTime)
        {

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            // Game State FSM
            switch (gameState)
            {
                case GameState.Menu:
                    menuTimer += gameTime.ElapsedGameTime.TotalSeconds;
                    if (menuTimer > .5)
                    {
                        Color temp = menuColor1;
                        menuColor1 = menuColor2;
                        menuColor2 = menuColor3;
                        menuColor3 = menuColor4;
                        menuColor4 = temp;
                        menuTimer = 0;
                    }

                    // Start game after hitting enter
                    if (Keyboard.GetState().IsKeyDown(Keys.Enter))
                    {
                        RoomManager.RecycleRooms();
                        itemFill();

                        if (currRoom.item != null)
                        {
                            currItem = items[rng.Next(items.Count)];
                            currItem.Active = true;
                            currItem.X = currRoom.item.X;
                            currItem.Y = currRoom.item.Y;
                        }

                        levels = 0;
                        p.Health = 5;
                        p.Speed = 4;
                        gameState = GameState.Gameplay;
                        godmode = false;
                    }

                    if (Keyboard.GetState().IsKeyDown(Keys.G))
                    {
                        RoomManager.RecycleRooms();
                        itemFill();

                        if (currRoom.item != null)
                        {
                            currItem = items[rng.Next(items.Count)];
                            currItem.Active = true;
                            currItem.X = currRoom.item.X;
                            currItem.Y = currRoom.item.Y;
                        }

                        levels = 0;
                        p.Health = 5;
                        gameState = GameState.Gameplay;
                        godmode = true;
                    }
                    break;

                // normal gameplay
                case GameState.Gameplay:

                    if (levels == 4)
                    {
                        gameState = GameState.Win;
                        return;
                    }

                    if (p.Health <= 0 && !godmode)
                    {
                        gameState = GameState.Lose;
                        break;
                    }

                    p.Move();
                    p.WallCollision(obstacleRects);

                    //handles wall bouncing, bool values are set in Entity.WallCollision()
                    if (p.BounceRight && !p.OnGround)
                    {
                        p.entityVelocity.X = 3;
                    }
                    else if (p.BounceLeft && !p.OnGround)
                    {
                        p.entityVelocity.X = -3;
                    }
                    else
                    {
                        p.entityVelocity.X = 0;
                        p.BounceRight = false;
                        p.BounceLeft = false;
                    }

                    foreach (Entity em in roomEnemies)
                    {
                        if (em is Enemy && !(em is GunEnemy))
                        {
                            e = (Enemy)em;
                            e.MoveEnemy();
                            e.WallCollision(obstacleRects);
                            e.FloorCheck(obstacleRects);
                            e.WallCheck(obstacleRects);
                        }
                        if (em is GunEnemy)
                        {
                            g = (GunEnemy)em;
                            g.MoveEnemy();
                            g.WallCollision(obstacleRects);
                            g.FloorCheck(obstacleRects);
                            g.WallCheck(obstacleRects);
                            g.CooldownTime += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                            g.Attack(p, 1);
                        }
                        if (em is FloatingEnemy)
                        {
                            f = (FloatingEnemy)em;
                            f.MoveEnemy(p);
                            f.Attack();
                        }
                    }

                    for (int i1 = 0; i1 < roomEnemies.Count; i1++)
                    {
                        Entity em = roomEnemies[i1];
                        if (p.LocationRect.Intersects(em.LocationRect))
                        {
                            if (em is Enemy && !(em is GunEnemy))
                            {
                                p.PosX = currRoom.PlayerSpawn.X;
                                p.PosY = currRoom.PlayerSpawn.Y;
                                p.entityVelocity.Y = 0;
                                p.Health--;
                            }
                            if (em is FloatingEnemy)
                            {
                                f = (FloatingEnemy)em;
                                p.PosX = currRoom.PlayerSpawn.X;
                                p.PosY = currRoom.PlayerSpawn.Y;
                                p.entityVelocity.Y = 0;
                                p.Health -= 3;
                                roomEnemies.Remove(em);
                            }
                        }
                        if (em is GunEnemy)
                        {
                            g = (GunEnemy)em;
                            for (int i = 0; i < g.ShotBullets.Count; i++)
                            {
                                g.ShotBullets[i].Move(obstacleRects);
                                if (g.ShotBullets[i].LocationRect.Intersects(p.LocationRect))
                                {
                                    p.Health--;
                                    g.ShotBullets.RemoveAt(i);
                                    i--;
                                }
                            }
                        }
                    }

                    if (p.position.Y < 0)
                    {
                        p.position.Y = 0;
                        p.entityVelocity.Y *= -.1f;
                    }

                    //Item Collision
                    if (currItem != null)
                    {
                        if (p.LocationRect.Intersects(currItem.Location))
                        {
                            currItem.Active = false;
                            p.ItemPickup(currItem);
                            currItem = null;
                        }
                    }

                    ScreenBounds();

                    break;

                case GameState.Win:

                    //Press Enter to return to title screen
                    if ((Keyboard.GetState().IsKeyDown(Keys.Enter) || Keyboard.GetState().IsKeyDown(Keys.Space)) && !prevKBS.IsKeyDown(Keys.Space))
                    {
                        gameState = GameState.Menu;
                    }
                    break;

                case GameState.Lose:

                    //Press Enter to return to title screen
                    if ((Keyboard.GetState().IsKeyDown(Keys.Enter) || Keyboard.GetState().IsKeyDown(Keys.Space)) && !prevKBS.IsKeyDown(Keys.Space))
                    {
                        p.PosX = currRoom.PlayerSpawn.X;
                        p.PosY = currRoom.PlayerSpawn.Y;
                        gameState = GameState.Menu;
                    }
                    break;

            }

            prevKBS = Keyboard.GetState();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightBlue);

            _spriteBatch.Begin();

            switch (gameState)
            {
                case GameState.Menu:
                    // Display Title Screen

                    // draw the squares
                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(0, 0, screenWidth / 2, screenHeight / 2),
                        menuColor1
                        );
                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(screenWidth / 2, 0, screenWidth / 2, screenHeight / 2),
                        menuColor2
                        );
                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(0, screenHeight / 2, screenWidth / 2, screenHeight / 2),
                        menuColor3
                        );
                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(screenWidth / 2, screenHeight / 2, screenWidth / 2, screenHeight / 2),
                        menuColor4
                        );

                    // draw lines to seperate them
                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(screenWidth / 2 - screenWidth / 40, 0, screenWidth / 20, screenHeight),
                        Color.Black);

                    _spriteBatch.Draw(wallTexture,
                        new Rectangle(0, screenHeight / 2 - screenWidth / 40, screenWidth, screenWidth / 20),
                        Color.Black);

                    // TEMPORARY
                    _spriteBatch.DrawString(titleText, "DISCO", new Vector2(Game1.screenWidth / 2 - 100, Game1.screenHeight / 10), menuColor4);
                    _spriteBatch.DrawString(titleText, "DUNGEON", new Vector2(Game1.screenWidth / 2 - 160, Game1.screenHeight / 10 + Game1.screenHeight / 20), menuColor3);

                    _spriteBatch.DrawString(debugText, "Press enter to start", new Vector2(Game1.screenWidth / 2 - 100, Game1.screenHeight / 2 - 40), menuColor2);
                    _spriteBatch.DrawString(debugText, "Press escape to quit", new Vector2(Game1.screenWidth / 2 - 100, Game1.screenHeight / 2 + 10), menuColor1);
                    _spriteBatch.DrawString(debugText, "Press g to start in godmode", new Vector2(Game1.screenWidth / 2 - 100, Game1.screenHeight / 2 - 15), menuColor4);

                    break;

                case GameState.Gameplay:

                    currRoom.Draw(_spriteBatch);

                    if (currItem != null)
                    {
                        currItem.Draw(_spriteBatch);
                    }

                    _spriteBatch.DrawString(debugText, "Health: " + p.Health, new Vector2(100, 20), Color.WhiteSmoke);
                    _spriteBatch.DrawString(debugText, "Speed: " + p.Speed, new Vector2(100, 40), Color.WhiteSmoke);

                    p.Draw(_spriteBatch);
                    foreach (Entity em in roomEnemies)
                    {
                        if (em is Enemy)
                        {
                            e = (Enemy)em;
                            e.Draw(_spriteBatch);
                        }
                        if (em is GunEnemy)
                        {
                            g = (GunEnemy)em;
                            g.Draw(_spriteBatch);

                        }
                        if (em is FloatingEnemy)
                        {
                            f = (FloatingEnemy)em;
                            f.Draw(_spriteBatch);
                        }
                    }
                    //f.Draw(_spriteBatch);
                    //_spriteBatch.Draw(playerTexture, e.FloorChecki, Color.Yellow);
                    //_spriteBatch.Draw(playerTexture, e.WallChecki, Color.Red);

                    //Debug
                    //_spriteBatch.DrawString(debugText, $"X Velocity: {p.entityVelocity.X}, Y Velocity: {p.entityVelocity.Y}," +
                    //$" X Pos: {p.position.X}, Y Pos: {p.position.Y}" + $", X Loc: {p.LocationRect.X}, Y Loc: {p.LocationRect.Y}",
                    //new Vector2(100, 20), Color.Black);

                    break;

                case GameState.Win:
                    // Display Win Screen
                    GraphicsDevice.Clear(Color.Black);

                    // TEMPORARY
                    _spriteBatch.DrawString(titleText, "YOU", new Vector2(Game1.screenWidth / 2 - 150, Game1.screenHeight / 2 - 150), menuColor2);
                    _spriteBatch.DrawString(titleText, "WIN", new Vector2(Game1.screenWidth / 2, Game1.screenHeight / 2 - 150), menuColor1);

                    _spriteBatch.DrawString(titleText, "Press enter to restart", new Vector2(Game1.screenWidth / 2 - 200, Game1.screenHeight / 2 - 40), Color.White);
                    _spriteBatch.DrawString(titleText, "Press space to go to menu", new Vector2(Game1.screenWidth / 2 - 200, Game1.screenHeight / 2 + 10), Color.White);


                    break;

                case GameState.Lose:
                    // Display Lose Screen
                    GraphicsDevice.Clear(Color.Black);

                    // TEMPORARY
                    _spriteBatch.DrawString(titleText, "YOU", new Vector2(Game1.screenWidth / 2 - 150, Game1.screenHeight / 2 - 150), menuColor2);
                    _spriteBatch.DrawString(titleText, "LOSE", new Vector2(Game1.screenWidth / 2, Game1.screenHeight / 2 - 150), menuColor1);

                    _spriteBatch.DrawString(titleText, "Press enter to restart", new Vector2(Game1.screenWidth / 2 - 200, Game1.screenHeight / 2 - 40), Color.White);
                    _spriteBatch.DrawString(titleText, "Press space to go to menu", new Vector2(Game1.screenWidth / 2 - 200, Game1.screenHeight / 2 + 10), Color.White);


                    break;

            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
