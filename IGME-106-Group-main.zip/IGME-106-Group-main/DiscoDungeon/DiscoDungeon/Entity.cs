﻿//Deegan Melchiondo
//3/16/2022
//Handles all things all entities have.

//3/16/2022 Only working on player things right now - Deegan

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DiscoDungeon
{
    public class Entity
    {
        private Texture2D texture;
         
        private bool active;
        protected Rectangle location;
        public Vector2 position;
        private float speed;
        private int damage;
        private bool facingRight;
        private bool onGround;
        private bool bounceLeft;
        private bool bounceRight;

        public Vector2 entityVelocity;
        protected Vector2 jumpVelocity;
        protected Vector2 gravity;

        /// <summary>
        /// Returns whether or not the Entity is active within the game at the moment
        /// </summary>
        public bool Active
        {
            get { return active; }

            set { active = value; }
        }

        /// <summary>
        /// Get or set the X coordinate of the Entity's location rectangle
        /// </summary>
        public int X
        {
            get { return location.X; }

            set { location.X = value; }
        }

        /// <summary>
        ///  Get or set the Y coordinate of the Entity's location rectangle
        /// </summary>
        public int Y
        {
            get { return location.Y; }

            set { location.Y = value; }
        }

        /// <summary>
        /// Get or set the X coordinate of the Entity's position (NOT LOCATION)
        /// </summary>
        public float PosX
        {
            get { return position.X; }

            set { position.X = value; }
        }

        /// <summary>
        /// Get or set the Y coordinate of the Entity's position (NOT LOCATION)
        /// </summary>
        public float PosY
        {
            get { return position.Y; }

            set { position.Y = value; }
        }

        /// <summary>
        /// Returns the rectangle object that represents the player
        /// </summary>
        public Rectangle LocationRect { get { return location; } }

        /// <summary>
        /// Get or change the speed of the Entity
        /// </summary>
        public float Speed
        {
            get { return speed; }

            set { speed = value; }
        }

        /// <summary>
        /// Returns if the Entity is facing screen right
        /// </summary>
        public bool FacingRight
        {
            get { return facingRight; }

            set { facingRight = value; }
        }

        /// <summary>
        /// Get or set if the player is bouncing off of a wall and being sent right
        /// </summary>
        public bool BounceRight
        {
            get { return bounceRight; }

            set { bounceRight = value; }
        }

        /// <summary>
        /// Get or set if the player is bouncing off of a wall and being sent left
        /// </summary>
        public bool BounceLeft
        {
            get { return bounceLeft; }

            set { bounceLeft = value; }
        }

        public bool OnGround
        {
            get { return onGround; }

            set { onGround = value; }
        }

        /// <summary>
        /// Creates an Entity object, NOTE: Entity starts facing right by default
        /// </summary>
        /// <param name="texture">Texture used for the entity. NOTE: location rectangle uses image bounds</param>
        /// <param name="speed">Starting speed for Entity. The only speed change should be the player's if they obtain an item</param>
        /// <param name="damage">How much damage the Entity does, if applicable</param>
        public Entity(Texture2D texture, int x, int y, float speed, int damage)
        {
            this.texture = texture;
            location = new Rectangle(x, y, texture.Width, texture.Height);
            position.X = x;
            position.Y = y;
            this.speed = speed;
            this.damage = damage;

            facingRight = true;
            active = false;
        }

        /// <summary>
        /// Draws the entity on the screen. Called within Game1 Draw
        /// </summary>
        public virtual void Draw(SpriteBatch sb)
        {
            sb.Draw(texture, LocationRect, Color.White);
        }

        /// <summary>
        /// Checks if this entity is colliding with a wall
        /// </summary>
        public void WallCollision(List<Rectangle> walls)
        {
            foreach (Rectangle wallLoc in walls)
            {
                if (LocationRect.Intersects(wallLoc))
                {
                    Rectangle intersect = Rectangle.Intersect(LocationRect, wallLoc);

                    if (intersect.Width > intersect.Height)
                    {
                        //up
                        if (wallLoc.Y < LocationRect.Y)
                        {
                            location.Y += intersect.Height;
                            entityVelocity.Y *= -.1f;
                        }
                        //down
                        if (wallLoc.Y > LocationRect.Y)
                        {
                            
                            location.Y -= intersect.Height;
                            entityVelocity.Y = 0;
                            onGround = true;
                        }

                        position.Y = location.Y;
                    }
                    if (intersect.Width < intersect.Height)
                    {
                        //Left
                        if (wallLoc.X > LocationRect.X)
                        {
                            location.X -= intersect.Width;
                            bounceLeft = true;
                        }
                        //Right
                        if (wallLoc.X < LocationRect.X)
                        {
                            location.X += intersect.Width;
                            bounceRight = true;
                        }

                        position.X = location.X;
                    }
                }
            }
        }

        /// <summary>
        /// Helper method within player that updates the Entity location variable for collision reasons
        /// </summary>
        public void UpdateLocation()
        {
            location.X = (int)position.X;
            location.Y = (int)position.Y;
        }

        /// <summary>
		/// Applies gravity to the entity
		/// </summary>
		protected void ApplyGravity()
        {
            position += entityVelocity;
            entityVelocity += gravity;
        }
    }
}