﻿//Deegan Melchiondo
//4/22/2022

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DiscoDungeon
{
    public class Item
    {
        string name;
        Texture2D texture;
        Rectangle location;

        int healthMod;
        float speedMod;
        //int damageMod;
        bool active;

        /// <summary>
        /// Get the item's location
        /// </summary>
        public Rectangle Location
        {
            get { return location; }
        }

        /// <summary>
        /// Get or set the item's x location
        /// </summary>
        public int X
        {
            get { return location.X; }

            set { location.X = value; }
        }

        /// <summary>
        /// Get or set the item's y location
        /// </summary>
        public int Y
        {
            get { return location.Y; }

            set { location.Y = value; }
        }

        /// <summary>
        /// Get the item's health modifier
        /// </summary>
        public int HealthMod
        {
            get { return healthMod; }
        }

        /// <summary>
        /// Get the item's speed modifier
        /// </summary>
        public float SpeedMod
        {
            get { return speedMod; }
        }

        /// <summary>
        /// Get or set if the item is currently active, and should be drawn and checked for hitboxes
        /// </summary>
        public bool Active
        {
            get { return active; }

            set { active = value; }
        }

        /// <summary>
        /// Creates an item with the specified stats
        /// </summary>
        public Item(string name, Texture2D texture, int healthMod, 
            float speedMod)
        {
            this.name = name;
            this.texture = texture;
            location = new Rectangle(0, 0, texture.Width, texture.Height);
            this.healthMod = healthMod;
            this.speedMod = speedMod;
            active = false;
        }

        /// <summary>
        /// Item draw method
        /// </summary>
        /// <param name="sb"></param>
        public void Draw(SpriteBatch sb)
        {
            if (active)
            {
                sb.Draw(texture, location, Color.White);
            }
        }
    }
}
