﻿// Dylan Daccarett
// 4/8/2022
// Handling floating enemy movement and behavior.
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DiscoDungeon
{
    class FloatingEnemy : Entity
    {
        private Rectangle attackRange;
        private double xMultiplier;
        private double yMultiplier;
        private float speed;
        public FloatingEnemy(Texture2D texture, int x, int y, float speed, int damage) : base(texture, x, y, speed, damage)
        {
            this.speed = speed;
            entityVelocity = Vector2.Zero;
            jumpVelocity = new Vector2(0, -10.0f);
            gravity = new Vector2(0, 0.5f);
            FacingRight = true;
        }

        public void MoveEnemy(Player player)
        {
            if (LocationRect.X == player.LocationRect.X)
            {
                yMultiplier = .5;
                xMultiplier = 0;
            }
            else if (LocationRect.Y == player.LocationRect.Y)
            {
                yMultiplier = 0;
                xMultiplier = .5;
            }
            else
            {
                double hypotenuse = Math.Pow(Math.Pow(LocationRect.X - player.LocationRect.X, 2) + Math.Pow(LocationRect.Y - player.LocationRect.Y, 2), .5);
                yMultiplier = Math.Acos(Math.Abs(LocationRect.X - player.LocationRect.X) / hypotenuse) / Math.PI;
                xMultiplier = Math.Acos(Math.Abs(LocationRect.Y - player.LocationRect.Y) / hypotenuse) / Math.PI;
            }
            if(LocationRect.X - player.LocationRect.X < 0)
            {
                if(LocationRect.Y - player.LocationRect.Y < 0)
                {
                    position.X += (float)xMultiplier * speed;
                    position.Y += (float)yMultiplier * speed;
                }
                else
                {
                    position.X += (float)xMultiplier * speed;
                    position.Y -= (float)yMultiplier * speed;
                }
            }
            else
            {
                if (LocationRect.Y - player.LocationRect.Y < 0)
                {
                    position.X -= (float)xMultiplier * speed;
                    position.Y += (float)yMultiplier * speed;
                }
                else
                {
                    position.X -= (float)xMultiplier * speed;
                    position.Y -= (float)yMultiplier * speed;
                }
            }
            UpdateLocation();
        }

        public void Attack()
        {

        }
    }
}
