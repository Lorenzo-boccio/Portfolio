﻿// Dylan Daccarett
// 3/25/2022
// Handling non-floating enemy movement and behavior.
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace DiscoDungeon
{
    class Enemy : Entity
    {
        public int damageDealt = 0;
        protected Rectangle floorCheck;
        protected Rectangle wallCheck;
        protected Rectangle attackRange;
        private bool intersected;
        private bool attackActive;
        private GameTime gameTime = new GameTime();
        public Rectangle FloorChecki
        {

            get { return floorCheck; }
        }
        public Rectangle WallChecki
        {
            get { return wallCheck; }
        }
        public Rectangle AttackRange
        {
            get { return attackRange; }
        }

        public Enemy(Texture2D texture, int x, int y, float speed, int damage) : base(texture, x, y, speed, damage)
        {
            attackActive = false;
            attackRange = new Rectangle((int)position.X + texture.Width + 10, (int)position.Y, 40, texture.Height);
            floorCheck = new Rectangle((int)position.X + texture.Width + 10, (int)position.Y + texture.Height, 50, 10);
            wallCheck = new Rectangle((int)position.X + texture.Width + 10, (int)position.Y, 10, texture.Height / 2);
            entityVelocity = Vector2.Zero;
            jumpVelocity = new Vector2(0, -10.0f);
            gravity = new Vector2(0, 0.5f);
            FacingRight = true;
        }
        /// <summary>
        /// Will attack the player if they enter its range for an amount of damage.
        /// </summary>
        /// <param name="player"></param>
        /// <param name="damage"></param>
        public virtual void Attack(Player player, int damage)
        {
            float timeToAttack;
            if(attackRange.Intersects(player.LocationRect))
            {
                damageDealt += damage;
            }
        }
        /// <summary>
        /// Moves the enemy in the direction it is facing.
        /// </summary>
        public virtual void MoveEnemy()
        {
            if (FacingRight)
            {
                floorCheck.X += (int)Speed;
                position.X += Speed;
            }
            else
            {
                floorCheck.X -= (int)Speed;
                position.X -= Speed;
            }
            if(FacingRight)
            {
                attackRange.X = this.LocationRect.X + LocationRect.Width;
                attackRange.Y = this.LocationRect.Y;
                floorCheck.X = this.LocationRect.X + LocationRect.Width;
                wallCheck.X = this.LocationRect.X + LocationRect.Width;
            }
            else
            {
                attackRange.X = this.LocationRect.X - LocationRect.Width + attackRange.Width;
                attackRange.Y = this.LocationRect.Y;
                floorCheck.X = this.LocationRect.X - floorCheck.Width;
                wallCheck.X = this.LocationRect.X - wallCheck.Width;
            }
            floorCheck.Y = (int)position.Y + LocationRect.Height;
            wallCheck.Y = (int)position.Y;
            ApplyGravity();
            UpdateLocation();
        }
        /// <summary>
        /// Changes the enemy's direction whenever it is about to walk off of a platform.
        /// </summary>
        /// <param name="walls"></param>
        public void FloorCheck(List<Rectangle> walls)
        {
            intersected = false;
            foreach (Rectangle wallLoc in walls)
            {
                if (floorCheck.Intersects(wallLoc))
                {
                    intersected = true;
                }
            }
            if (!intersected)
            {
                if (FacingRight)
                {
                    FacingRight = false;
                    floorCheck.X = floorCheck.X - (LocationRect.Width) - 20;
                }
                else
                {
                    FacingRight = true;
                    floorCheck.X = floorCheck.X + (LocationRect.Width) + 20;
                }
            }
        }

        public void WallCheck(List<Rectangle> walls)
        {
            intersected = false;
            foreach (Rectangle wallLoc in walls)
            {
                if (wallCheck.Intersects(wallLoc))
                {
                    intersected = true;
                }
            }
            if (intersected)
            {
                if (FacingRight)
                {
                    FacingRight = false;
                    wallCheck.X = wallCheck.X - (LocationRect.Width);
                }
                else
                {
                    FacingRight = true;
                    wallCheck.X = wallCheck.X + (LocationRect.Width);
                }
            }
        }
    }
}
