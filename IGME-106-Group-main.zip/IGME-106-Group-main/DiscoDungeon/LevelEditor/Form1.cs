﻿// Matt Tompetrini
// Disco Dungeon Level Editor

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LevelEditor
{
    public partial class Form1 : Form
    {
        // Fields
        Image selectedTile;
        Color bgColor;
        int width;
        int height;
        bool fileSaved; 

        public Form1()
        {
            selectedTile = Properties.Resources.DiscoTile;
            Color bgColor = Color.ForestGreen;
            width = 62;
            height = 34;
            fileSaved = true;

            InitializeComponent();

            int tileX = 20;
            int tileY = 20;
            int tileDimensions = 20;
            int rowLength = 0;
            int tileCount = 0;

            // Generate grid of blank tiles to create empty map
            while (tileCount < width * height)
            {
                // Create Tile
                PictureBox tile = new PictureBox();
                Point tilePosition = new Point(tileX, tileY);
                tile.Size = new Size(tileDimensions, tileDimensions);
                tile.BackColor = Color.Transparent;
                tile.Location = tilePosition;
                tile.BackgroundImageLayout = ImageLayout.Stretch;

                // Hook up method
                tile.Click += ChangeTileColor;
                

                // Add tile
                groupBoxMap.Controls.Add(tile);

                // Increment position-related numbers
                tileX += tileDimensions;
                rowLength++;
                tileCount++;

                // Move to next row
                if (rowLength == width)
                {
                    tileX = 20;
                    tileY += tileDimensions;
                    rowLength = 0;
                }
            }
        }

        /// <summary>
        /// Changes current selected color to the color of the swatch clicked by user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void SelectColor(object sender, EventArgs e)
        {
            Button colorSwatch = (Button)sender;

            // Select color and display as selected color 
            
            selectedTile = colorSwatch.BackgroundImage;
            bgColor = colorSwatch.BackColor;

            buttonCurrentTile.BackgroundImage = selectedTile;
            buttonCurrentTile.BackColor = bgColor;

            // Update Label
            if(sender == buttonPlatform)
            {
                groupBoxCurrent.Text = "Current Tile: Platform Middle";
            }
            else if(sender == buttonEmpty)
            {
                groupBoxCurrent.Text = "Current Tile: None";
            }
            else if(sender == buttonPlayer)
            {
                groupBoxCurrent.Text = "Current Tile: Player Spawn";
            }
            else if(sender == buttonPlatformLeft)
            {
                groupBoxCurrent.Text = "Current Tile: Platform Left";
            }
            else if (sender == buttonPlatformRight)
            {
                groupBoxCurrent.Text = "Current Tile: Platform Right";
            }
            else if(sender == buttonItem)
            {
                groupBoxCurrent.Text = "Current Tile: Item Spawn";
            }
            else if(sender == buttonLegEnemy)
            {
                groupBoxCurrent.Text = "Current Tile: Leg Enemy";
            }
            else if(sender == buttonGunEnemy)
            {
                groupBoxCurrent.Text = "Current Tile: Gun Enemy";
            }
            else if(sender == buttonArmEnemy)
            {
                groupBoxCurrent.Text = "Current Tile: Arm Enemy";
            }

        }

        /// <summary>
        /// Changes tile color to current selected color when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ChangeTileColor(object sender, EventArgs e)
        {
            PictureBox box = (PictureBox)sender;

            // Display new unsaved changes in form's text
            if (fileSaved)
            {
                this.Text += "*";
            }
            fileSaved = false;

            box.BackgroundImage = selectedTile;
            box.BackColor = bgColor;
        }

        /// <summary>
        /// Saves the current created level file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void SaveFile(object sender, EventArgs e)
        {
            string fileName;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Save a level file";
            saveFileDialog.Filter = "Level Files | *.level";

            // Count number of player spawn points currently on map
            int playerSpawnCount = 0;
            int itemSpawnCount = 0;
            foreach(PictureBox tile in groupBoxMap.Controls)
            {
                if(tile.BackColor == Color.Pink)
                {
                    playerSpawnCount++;
                }

                if (tile.BackColor == Color.DarkViolet)
                {
                    itemSpawnCount++;
                }
            }

            // If there is multiple or 0 player spawns currently placed, show message box
            if(playerSpawnCount != 1 || itemSpawnCount > 1)
            {
                MessageBox.Show(
                        "There must be exactly 1 player spawn point and no more than 1 item to save a file",
                        "Error saving file",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                return;
            }


            // Write file once user selects path
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog.FileName;
                StreamWriter output = new StreamWriter(fileName);

                try
                {
                    // Write information for each tile
                    foreach (PictureBox tile in groupBoxMap.Controls)
                    {
                        // Empty Tile
                        if (tile.BackColor == Color.Transparent)
                        {
                            output.Write("Empty|");
                        }
                        // Middle Platform
                        else if (tile.BackColor == Color.ForestGreen)
                        {
                            output.Write("Platform_Mid|");
                        }
                        // Platform Left
                        else if(tile.BackColor == Color.OrangeRed)
                        {
                            output.Write("Platform_Left|");
                        }
                        // Platform Right
                        else if(tile.BackColor == Color.DodgerBlue)
                        {
                            output.Write("Platform_Right|");
                        }
                        // Enemy Spawn
                        else if(tile.BackColor == Color.Chocolate)
                        {
                            output.Write("Leg_Enemy|");
                        }
                        // Item Spawn
                        else if(tile.BackColor == Color.DarkViolet)
                        {
                            output.Write("Item_Spawn|");
                        }
                        // Gun Enemy
                        else if(tile.BackColor == Color.Yellow)
                        {
                            output.Write("Gun_Enemy|");
                        }
                        // Player Spawn
                        else if(tile.BackColor == Color.Pink)
                        {
                            output.Write("Player_Spawn|");
                        }
                        // Arm Enemy
                        else if(tile.BackColor == Color.SaddleBrown)
                        {
                            output.Write("Arm_Enemy|");
                        }
                        // For occasional bug where color isn't read properly for platforms
                        else
                        {
                            output.Write("Platform_Mid|");
                        }

                        // Write X and Y
                        output.Write($"{tile.Location.X * 3 / 2}|");
                        output.WriteLine(tile.Location.Y * 3 / 2);
                       
                    }

                    output.Close();

                    // Update boolean and change text to remove asterisk
                    fileSaved = true;
                    this.Text = $"Level Editor - {fileName} ";

                    // Display successful message box
                    MessageBox.Show(
                        "File saved successfully.",
                        "File saved",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                // Display error message box if exception occurs
                catch (Exception ex)
                {
                    MessageBox.Show(
                        ex.Message,
                        "Error saving file",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Open and display a level file selected by the user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void LoadFile(object sender, EventArgs e)
        {
            // Display Dialog
            string fileName;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Open a level file";
            openFileDialog.Filter = "Level Files | *.level";

            // Open selected file
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Clear Current Tiles
                groupBoxMap.Controls.Clear();

                // Prompt user to select file
                fileName = openFileDialog.FileName;

                // Open Reader
                StreamReader input = new StreamReader(fileName);
                try
                {
                    int tileDimensions = 20;

                    // Go line by line reading tile info
                    string line = null;
                    while ((line = input.ReadLine()) != null)
                    {
                        // Create Tile
                        PictureBox tile = new PictureBox();

                        // Get information
                        string[] tileInfo = line.Split('|');

                        // Set tile color based on info
                        switch (tileInfo[0])
                        {
                            // Empty
                            case "Empty":
                                tile.BackColor = Color.Transparent;
                                break;

                            // Middle Platform
                            case "Platform_Mid":
                                tile.BackColor = Color.ForestGreen;
                                tile.BackgroundImage = Properties.Resources.DiscoTile;
                                break;

                            // Left Platform
                            case "Platform_Left":
                                tile.BackColor = Color.OrangeRed;
                                tile.BackgroundImage = Properties.Resources.DiscoTile;
                                break;

                            // Right Platform
                            case "Platform_Right":
                                tile.BackColor = Color.DodgerBlue;
                                tile.BackgroundImage = Properties.Resources.DiscoTile;
                                break;

                            // Enemy
                            case "Leg_Enemy":
                                tile.BackColor = Color.Chocolate;
                                tile.BackgroundImage = Properties.Resources.LegBoy;
                                break;

                            // Item
                            case "Item_Spawn":
                                tile.BackColor = Color.DarkViolet;
                                tile.BackgroundImage = Properties.Resources.ItemIcon;
                                break;

                            // Gun Enemy
                            case "Gun_Enemy":
                                tile.BackColor = Color.Yellow;
                                tile.BackgroundImage = Properties.Resources.GunBass;
                                break;

                            // Player Spawn
                            case "Player_Spawn":
                                tile.BackColor = Color.Pink;
                                tile.BackgroundImage = Properties.Resources.PlayerIcon;
                                break;

                            // Arm Enemy
                            case "Arm_Enemy":
                                tile.BackColor = Color.SaddleBrown;
                                tile.BackgroundImage = Properties.Resources.ArmBoy;
                                break;
                        }

                        // Read Coordinates
                        int tileX = int.Parse(tileInfo[1]) * 2 / 3;
                        int tileY = int.Parse(tileInfo[2]) * 2 / 3;

                        // Set Size and Position
                        Point tilePosition = new Point(tileX, tileY);
                        tile.Size = new Size(tileDimensions, tileDimensions);
                        tile.Location = tilePosition;
                        tile.BackgroundImageLayout = ImageLayout.Stretch;

                        // Hook up method
                        tile.Click += ChangeTileColor;

                        // Add tile
                        groupBoxMap.Controls.Add(tile);
                    }
                    
                    input.Close();
                    fileSaved = true;

                    // Display successful message box and update form text
                    MessageBox.Show(
                        "File loaded successfully.",
                        "File loaded",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    this.Text = $"Level Editor - {fileName} ";
                }
                // Display error message box if exception occurs
                catch (Exception ex)
                {
                    MessageBox.Show(
                        ex.Message,
                        "Error loading file",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Prompts the user to save if they attempt to close the form without saving
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void PromptUnsavedChanges(object sender, FormClosingEventArgs e)
        {
            if (!fileSaved)
            {
                // Display message box
                DialogResult result = MessageBox.Show(
                    "There are unsaved changes. Are you sure you want to quit?",
                    "Unsaved changes",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                // Return to editor if "No" is chosen
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// Allows the user to reset the current level being created,
        /// more convenient than manually clicking each box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ClearCurrentMap(object sender, EventArgs e)
        {
            // Display message box
            DialogResult result = MessageBox.Show(
                "Do you want to clear the current level?",
                "Clear Level",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            // If yes is selected, set all tiles to Empty
            if (result == DialogResult.Yes)
            {
                // Loop and reset tile color and background image
                foreach (PictureBox tile in groupBoxMap.Controls)
                {
                    tile.BackColor = Color.Transparent;
                    tile.BackgroundImage = null;
                }
            }
        }
    }
}
