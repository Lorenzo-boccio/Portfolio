﻿
namespace LevelEditor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxMap = new System.Windows.Forms.GroupBox();
            this.groupBoxTiles = new System.Windows.Forms.GroupBox();
            this.buttonArmEnemy = new System.Windows.Forms.Button();
            this.buttonPlayer = new System.Windows.Forms.Button();
            this.buttonGunEnemy = new System.Windows.Forms.Button();
            this.buttonItem = new System.Windows.Forms.Button();
            this.buttonPlatformRight = new System.Windows.Forms.Button();
            this.buttonPlatformLeft = new System.Windows.Forms.Button();
            this.buttonLegEnemy = new System.Windows.Forms.Button();
            this.buttonEmpty = new System.Windows.Forms.Button();
            this.buttonPlatform = new System.Windows.Forms.Button();
            this.groupBoxCurrent = new System.Windows.Forms.GroupBox();
            this.buttonCurrentTile = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBoxTiles.SuspendLayout();
            this.groupBoxCurrent.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxMap
            // 
            this.groupBoxMap.AutoSize = true;
            this.groupBoxMap.BackColor = System.Drawing.Color.Black;
            this.groupBoxMap.Location = new System.Drawing.Point(279, 12);
            this.groupBoxMap.Name = "groupBoxMap";
            this.groupBoxMap.Size = new System.Drawing.Size(1280, 720);
            this.groupBoxMap.TabIndex = 0;
            this.groupBoxMap.TabStop = false;
            this.groupBoxMap.Text = "Map";
            // 
            // groupBoxTiles
            // 
            this.groupBoxTiles.Controls.Add(this.buttonArmEnemy);
            this.groupBoxTiles.Controls.Add(this.buttonPlayer);
            this.groupBoxTiles.Controls.Add(this.buttonGunEnemy);
            this.groupBoxTiles.Controls.Add(this.buttonItem);
            this.groupBoxTiles.Controls.Add(this.buttonPlatformRight);
            this.groupBoxTiles.Controls.Add(this.buttonPlatformLeft);
            this.groupBoxTiles.Controls.Add(this.buttonLegEnemy);
            this.groupBoxTiles.Controls.Add(this.buttonEmpty);
            this.groupBoxTiles.Controls.Add(this.buttonPlatform);
            this.groupBoxTiles.Location = new System.Drawing.Point(11, 12);
            this.groupBoxTiles.Name = "groupBoxTiles";
            this.groupBoxTiles.Size = new System.Drawing.Size(250, 291);
            this.groupBoxTiles.TabIndex = 1;
            this.groupBoxTiles.TabStop = false;
            this.groupBoxTiles.Text = "Tile Selector";
            // 
            // buttonArmEnemy
            // 
            this.buttonArmEnemy.BackColor = System.Drawing.Color.SaddleBrown;
            this.buttonArmEnemy.BackgroundImage = global::LevelEditor.Properties.Resources.ArmBoy;
            this.buttonArmEnemy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonArmEnemy.Location = new System.Drawing.Point(167, 204);
            this.buttonArmEnemy.Name = "buttonArmEnemy";
            this.buttonArmEnemy.Size = new System.Drawing.Size(72, 73);
            this.buttonArmEnemy.TabIndex = 8;
            this.buttonArmEnemy.UseVisualStyleBackColor = false;
            this.buttonArmEnemy.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonPlayer
            // 
            this.buttonPlayer.BackColor = System.Drawing.Color.Pink;
            this.buttonPlayer.BackgroundImage = global::LevelEditor.Properties.Resources.PlayerIcon;
            this.buttonPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlayer.Location = new System.Drawing.Point(167, 45);
            this.buttonPlayer.Name = "buttonPlayer";
            this.buttonPlayer.Size = new System.Drawing.Size(72, 73);
            this.buttonPlayer.TabIndex = 7;
            this.buttonPlayer.UseVisualStyleBackColor = false;
            this.buttonPlayer.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonGunEnemy
            // 
            this.buttonGunEnemy.BackColor = System.Drawing.Color.Yellow;
            this.buttonGunEnemy.BackgroundImage = global::LevelEditor.Properties.Resources.GunBass;
            this.buttonGunEnemy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonGunEnemy.Location = new System.Drawing.Point(89, 204);
            this.buttonGunEnemy.Name = "buttonGunEnemy";
            this.buttonGunEnemy.Size = new System.Drawing.Size(72, 73);
            this.buttonGunEnemy.TabIndex = 6;
            this.buttonGunEnemy.UseVisualStyleBackColor = false;
            this.buttonGunEnemy.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonItem
            // 
            this.buttonItem.BackColor = System.Drawing.Color.DarkViolet;
            this.buttonItem.BackgroundImage = global::LevelEditor.Properties.Resources.ItemIcon;
            this.buttonItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonItem.Location = new System.Drawing.Point(167, 125);
            this.buttonItem.Name = "buttonItem";
            this.buttonItem.Size = new System.Drawing.Size(72, 73);
            this.buttonItem.TabIndex = 5;
            this.buttonItem.UseVisualStyleBackColor = false;
            this.buttonItem.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonPlatformRight
            // 
            this.buttonPlatformRight.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonPlatformRight.BackgroundImage = global::LevelEditor.Properties.Resources.DiscoTile;
            this.buttonPlatformRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlatformRight.Location = new System.Drawing.Point(89, 125);
            this.buttonPlatformRight.Name = "buttonPlatformRight";
            this.buttonPlatformRight.Size = new System.Drawing.Size(72, 73);
            this.buttonPlatformRight.TabIndex = 4;
            this.buttonPlatformRight.UseVisualStyleBackColor = false;
            this.buttonPlatformRight.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonPlatformLeft
            // 
            this.buttonPlatformLeft.BackColor = System.Drawing.Color.OrangeRed;
            this.buttonPlatformLeft.BackgroundImage = global::LevelEditor.Properties.Resources.DiscoTile;
            this.buttonPlatformLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlatformLeft.Location = new System.Drawing.Point(11, 125);
            this.buttonPlatformLeft.Name = "buttonPlatformLeft";
            this.buttonPlatformLeft.Size = new System.Drawing.Size(72, 73);
            this.buttonPlatformLeft.TabIndex = 3;
            this.buttonPlatformLeft.UseVisualStyleBackColor = false;
            this.buttonPlatformLeft.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonLegEnemy
            // 
            this.buttonLegEnemy.BackColor = System.Drawing.Color.Chocolate;
            this.buttonLegEnemy.BackgroundImage = global::LevelEditor.Properties.Resources.LegBoy;
            this.buttonLegEnemy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonLegEnemy.Location = new System.Drawing.Point(11, 204);
            this.buttonLegEnemy.Name = "buttonLegEnemy";
            this.buttonLegEnemy.Size = new System.Drawing.Size(72, 73);
            this.buttonLegEnemy.TabIndex = 2;
            this.buttonLegEnemy.UseVisualStyleBackColor = false;
            this.buttonLegEnemy.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonEmpty
            // 
            this.buttonEmpty.BackColor = System.Drawing.Color.Transparent;
            this.buttonEmpty.Location = new System.Drawing.Point(89, 47);
            this.buttonEmpty.Name = "buttonEmpty";
            this.buttonEmpty.Size = new System.Drawing.Size(72, 73);
            this.buttonEmpty.TabIndex = 1;
            this.buttonEmpty.UseVisualStyleBackColor = false;
            this.buttonEmpty.Click += new System.EventHandler(this.SelectColor);
            // 
            // buttonPlatform
            // 
            this.buttonPlatform.BackColor = System.Drawing.Color.ForestGreen;
            this.buttonPlatform.BackgroundImage = global::LevelEditor.Properties.Resources.DiscoTile;
            this.buttonPlatform.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonPlatform.Location = new System.Drawing.Point(11, 47);
            this.buttonPlatform.Name = "buttonPlatform";
            this.buttonPlatform.Size = new System.Drawing.Size(72, 73);
            this.buttonPlatform.TabIndex = 0;
            this.buttonPlatform.UseVisualStyleBackColor = false;
            this.buttonPlatform.Click += new System.EventHandler(this.SelectColor);
            // 
            // groupBoxCurrent
            // 
            this.groupBoxCurrent.Controls.Add(this.buttonCurrentTile);
            this.groupBoxCurrent.Location = new System.Drawing.Point(11, 309);
            this.groupBoxCurrent.Name = "groupBoxCurrent";
            this.groupBoxCurrent.Size = new System.Drawing.Size(250, 139);
            this.groupBoxCurrent.TabIndex = 2;
            this.groupBoxCurrent.TabStop = false;
            this.groupBoxCurrent.Text = "Current Tile: Platform Middle";
            // 
            // buttonCurrentTile
            // 
            this.buttonCurrentTile.BackColor = System.Drawing.Color.Transparent;
            this.buttonCurrentTile.BackgroundImage = global::LevelEditor.Properties.Resources.DiscoTile;
            this.buttonCurrentTile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCurrentTile.Enabled = false;
            this.buttonCurrentTile.Location = new System.Drawing.Point(72, 23);
            this.buttonCurrentTile.Name = "buttonCurrentTile";
            this.buttonCurrentTile.Size = new System.Drawing.Size(110, 109);
            this.buttonCurrentTile.TabIndex = 0;
            this.buttonCurrentTile.UseVisualStyleBackColor = false;
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(11, 493);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(117, 99);
            this.buttonSave.TabIndex = 3;
            this.buttonSave.Text = "Save File";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.SaveFile);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(135, 493);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(127, 99);
            this.buttonLoad.TabIndex = 4;
            this.buttonLoad.Text = "Load File";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.LoadFile);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 455);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 29);
            this.button1.TabIndex = 5;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ClearCurrentMap);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1568, 739);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonLoad);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.groupBoxCurrent);
            this.Controls.Add(this.groupBoxTiles);
            this.Controls.Add(this.groupBoxMap);
            this.Name = "Form1";
            this.Text = "Level Editor ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PromptUnsavedChanges);
            this.groupBoxTiles.ResumeLayout(false);
            this.groupBoxCurrent.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxMap;
        private System.Windows.Forms.GroupBox groupBoxTiles;
        private System.Windows.Forms.GroupBox groupBoxCurrent;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.Button buttonItem;
        private System.Windows.Forms.Button buttonPlatformRight;
        private System.Windows.Forms.Button buttonPlatformLeft;
        private System.Windows.Forms.Button buttonLegEnemy;
        private System.Windows.Forms.Button buttonEmpty;
        private System.Windows.Forms.Button buttonPlatform;
        private System.Windows.Forms.Button buttonCurrentTile;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonGunEnemy;
        private System.Windows.Forms.Button buttonPlayer;
        private System.Windows.Forms.Button buttonArmEnemy;
    }
}

