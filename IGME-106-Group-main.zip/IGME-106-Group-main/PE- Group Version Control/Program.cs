﻿using System;

//Lorenzo Boccio
//Deegan Melchiondo
//Dylan Daccarett
//Matt Tompetrini

namespace PE__Group_Version_Control
{
    class Program
    {
        //Problem #1- Deegan

        /// <summary>
        /// Rolls two six sided die until the sum matches the desired user entered sum
        /// </summary>
        public static void DiceSum()
        {
            Random rng = new Random();
            int userSum = 0;
            int d1 = 0;
            int d2 = 0;

            //Checks entered value until is is between the valid range (2-12)
            while (userSum < 2 || userSum > 12)
            {
                Console.Write("Desired dice sum: ");
                userSum = int.Parse(Console.ReadLine());

                if (userSum < 2 || userSum > 12)
                {
                    Console.WriteLine("Invalid sum\n");
                }
            }

            //Loop continues until sum is reached
            while ((d1 + d2) != userSum)
            {
                d1 = rng.Next(1, 7);
                d2 = rng.Next(1, 7);

                Console.WriteLine($"{d1} and {d2} = {d1 + d2}");
            }
        }


        // Problem #2 - Matt

        /// <summary>
        /// Accepts a first and last name and returns it formatted as "Last Name, First Initial"
        /// </summary>
        /// <param name="name">A person's first and last name</param>
        /// <returns>The person's last name followed by the first initial and a period</returns>
        public static string LastFirst(string name)
        {
            // Split name string into first and last
            string[] splitName = name.Split(" ");
            string firstName = splitName[0];
            string lastName = splitName[1];

            // Return last name, first initial
            return $"{lastName}, {firstName[0]}.";
        }

        // Problem #3- Dylan
        public static bool IsPalindrome(string word)
        {
            bool isPalindrome = true;
            word = word.Trim().ToLower();
            for (int i = 0; i < word.Length - 1; i++)
            {
                if (!(word[i].Equals(word[word.Length - 1 - i])))
                {
                    isPalindrome = false;
                    break;
                }
            }
            return isPalindrome;
        }

        // Problem #4 - Lorenzo

        /// <summary>
        /// takes an array of ints and returns the length of the longest sequence of sequential numbers
        /// </summary>
        /// <returns></returns>
        public static int LongestSortedSequence(int[] seq)
        {
            int longest = 0;
            int current = 1;
            // repeat for whole array
            for (int i = 1; i < seq.Length; i++)
            {
                if (seq[i] >= seq[i - 1])
                {
                    current++; // increase current count if its equal or larger
                }
                else
                {   // if its not then change longest to current if current is longer then set current to 1
                    if (current > longest) { longest = current; }
                    current = 1;
                }
            }
            return longest;
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Problem #1:\n");
            DiceSum();

            Console.WriteLine("\nProblem #2: ");
            Console.WriteLine(LastFirst("Mickey Mouse"));

            Console.WriteLine("\nProblem #3");
            Console.WriteLine(IsPalindrome("gohangasalamiimalasagnahog"));
            Console.WriteLine(IsPalindrome("Squeeeeeps"));

            // arrays for the method to use
            int[] arr1 = new int[12] { 3, 8, 10, 1, 9, 14, -3, 0, 14, 207, 56, 98 };
            int[] arr2 = new int[12] { 17, 42, 3, 5, 5, 5, 8, 2, 4, 6, 1, 19 };
            Console.WriteLine("\nProblem #4");
            Console.WriteLine("the array 3, 8, 10, 1, 9, 14, -3, 0, 14, 207, 56, 98 has the longest sorted sequence of " + LongestSortedSequence(arr1));
            Console.WriteLine("the array 17, 42, 3, 5, 5, 5, 8, 2, 4, 6, 1, 19 has the longest sorted sequence of " + LongestSortedSequence(arr2));
            Console.ReadKey();
        }
    }
}
