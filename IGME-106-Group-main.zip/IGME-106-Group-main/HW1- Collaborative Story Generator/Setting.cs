﻿//Name: Dylan Daccarett

//Holds Settings, which are locations with at least two bits of information
//A method called GenerateSetting should return a random setting's info
//to be read by the Story class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace HW1__Collaborative_Story_Generator
{
    class Setting
    {
        private string time;
        private string location;

        public string Time
        {
            get;
        }

        public string Location
        {
            get;
        }
        private string[] settingList;
        public List<Setting> settings = new List<Setting>();
        StreamReader input = null;

        public Setting()
        {
            Load();
        }

        public Setting(string location, string time)
        {
            Time = time;
            Location = location;
        }
        /// <summary>
        /// Loads the settings from the text file.
        /// </summary>
        public void Load()
        {
            try
            {
                input = new StreamReader("../../../settings.txt");
                string line = null;
                while ((line = input.ReadLine()) != null)
                {
                    settingList = line.Split('|');
                    settings.Add(new Setting(settingList[0], settingList[1]));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (input != null)
                {
                    input.Close();
                }
            }
        }
        Random rng = new Random();
        /// <summary>
        /// Returns a random setting from the setting list.
        /// </summary>
        /// <returns></returns>
        public string GenerateSetting()
        {
            return settings[rng.Next(0, settings.Count)].Location + "|" + settings[rng.Next(0, settings.Count)].Time;
        }
    }
}
