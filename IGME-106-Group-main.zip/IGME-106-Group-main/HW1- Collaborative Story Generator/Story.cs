﻿//Name: Deegan

//Takes a user inputted ending and generates a story using the Conflict, Actor, and Setting classes.
//Should not read the text file, but rather take the information from the other classes.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1__Collaborative_Story_Generator
{
    class Story
    {
        Setting setting;
        Conflict conflict;
        Actor actor;

        public Story()
        {
            setting = new Setting();
            conflict = new Conflict();
            actor = new Actor();
        }

        /// <summary>
        /// Generates a story using information from setting, conflict, and actor classes. User-inputted ending
        /// determines the content of the conflict
        /// </summary>
        /// <param name="ending"></param>
        public void GenerateStory(string ending)
        {
            string[] settings = setting.GenerateSetting().Split("|"); //Format: (time, location)
            string[] conflicts = conflict.GenerateConflict(ending).Split("|"); //Format: (ending, conflict, resolution)
            string[] actors = actor.GenerateActor().Split("|"); //Format: (name, physical description, profession)

            Console.WriteLine($"The story takes place in {settings[0]}, {settings[1]}. " +
                $"{actors[0]} is {actors[1]} and is a(n) {actors[2]}. " +
                $"\n{conflicts[1]}. {actors[0]} {conflicts[2]}");
        }
    }
}
