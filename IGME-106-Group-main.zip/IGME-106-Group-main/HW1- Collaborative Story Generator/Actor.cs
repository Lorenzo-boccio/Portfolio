﻿//Name: Lorenzo

//Holds Actors, which are characters with at least 3 bits of information.
//An internal array should read from a text file called Actors.txt and add that info
//A method called GenerateActor should return a random actor's information to be read by the Story class

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HW1__Collaborative_Story_Generator
{
    class Actor
    {
        string name;
        string physicalDescription;
        string profession;

        public string Name { get; }
        public string PhysicalDescription { get; }
        public string Profession { get; }

        private string[] actors;

        public List<string> actorList = new List<string>();

        StreamReader input = null;

        /// <summary>
        /// loads the information from the text file using the load method
        /// </summary>
        public Actor()
        {
            Load();
        }

        public Actor(string name, string physicalDescription, string proffesion)
        {
            Name = name;
            PhysicalDescription = physicalDescription;
            Profession = profession;

        }

        /// <summary>
        /// loads the entire actor.txt file into a list
        /// </summary>
        public void Load()
        {
            try
            {
                input = new StreamReader("../../../Actor.txt");
                string line = null;
                while ((line = input.ReadLine()) != null)
                {
                    actorList.Add(line);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                if (input != null)
                {
                    input.Close();
                }
            }
        }


        Random rng = new Random();
        /// <summary>
        /// creates a new actor using the presets in the actor.txt
        /// </summary>
        /// <returns></returns>
        public string GenerateActor()
        {
            return actorList[rng.Next(0, actorList.Count)] + "|" + actorList[rng.Next(0, actorList.Count)]
                + "|" + actorList[rng.Next(0, actorList.Count)];
        }
    }
}
