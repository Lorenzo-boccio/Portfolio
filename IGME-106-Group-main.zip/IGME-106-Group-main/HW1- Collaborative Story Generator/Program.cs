﻿//Group Members:
//Deegan Melchiondo
//
//
//

//Same person should work on Main and Story
//Name: Deegan

//Main should use the Story class to properly test the program.
//Any formatting errors should be apparent and fixed, hence why the same person should do
//Story and Main

using System;

namespace HW1__Collaborative_Story_Generator
{
    class Program
    {
        static void Main(string[] args)
        {
            Story story = new Story();
            bool quit = false;
            string userChoice;

            Console.WriteLine("Welcome to the story generator!\n");

            while (!quit)
            {
                Console.WriteLine("\nPlease choose a type of ending to generate a story:" +
                    "\n\'happy\'\t\t \'tragic\'\t \'romantic\'" +
                    "\n\'funny\'\t\t \'twist\'\t \'any ending\'\n");

                Console.Write("Your choice >> ");
                userChoice = Console.ReadLine().Trim().ToLower();

                //Note: Endings are switched to ints for simplicity in the story class
                switch (userChoice)
                {
                    case "happy":
                        story.GenerateStory("happy");
                        break;

                    case "tragic":
                        story.GenerateStory("tragic");
                        break;

                    case "romantic":
                        story.GenerateStory("romantic");
                        break;

                    case "funny":
                        story.GenerateStory("funny");
                        break;

                    case "twist":
                        story.GenerateStory("twist");
                        break;

                    case "any ending":
                        story.GenerateStory("any");
                        break;

                    default:
                        continue;
                }

                Console.Write("\nWould you like another story? Choose \'Yes\' or \'No\' >> ");
                userChoice = Console.ReadLine().Trim().ToLower();

                if (userChoice == "no")
                {
                    quit = true;
                }
            }
        }
    }
}
