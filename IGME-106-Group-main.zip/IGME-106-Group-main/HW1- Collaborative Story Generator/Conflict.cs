﻿//Name: Matt

//Holds Conflicts, which should contain a conflict, resolution, and ending.
//An internal array should read a textfile named Conflicts.txt and add the information
//A method called GenerateConflict should take in an ending type (can substitute this for numbers)
//and produce an according string for the Story class to take in.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HW1__Collaborative_Story_Generator
{
    class Conflict
    {
        // Fields
        List<string> listConflicts;

        /// <summary>
        /// Constructor
        /// </summary>
        public Conflict()
        {
            listConflicts = new List<string>();
            try
            {
                StreamReader input = new StreamReader("../../../conflict.txt");
                string line = null;
                while ((line = input.ReadLine()) != null)
                {
                    listConflicts.Add(line);
                }

                input.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }

        /// <summary>
        /// Loads settings from text file
        /// </summary>
        public string GenerateConflict(string endingType)
        {
            // Create subcategories for endings
            List<string> happyEndings = new List<string>();
            List<string> tragicEndings = new List<string>();
            List<string> romanticEndings = new List<string>();
            List<string> funnyEndings = new List<string>();
            List<string> twistEndings = new List<string>();
            
            // Random object
            Random rng = new Random();
            int indexChoice;

            // Sort conflicts into subcategories
            foreach(string conflict in listConflicts)
            {
                string[] conflictPieces = conflict.Split("|");
                
                // Add conflict to corresponding category
                switch(conflictPieces[0])
                {
                    case "happy":
                        happyEndings.Add(conflict);
                        break;

                    case "tragic":
                        tragicEndings.Add(conflict);
                        break;

                    case "romantic":
                        romanticEndings.Add(conflict);
                        break;

                    case "funny":
                        funnyEndings.Add(conflict);
                        break;

                    case "twist":
                        twistEndings.Add(conflict);
                        break;
                }
            }

            switch(endingType)
            {
                // Return happy ending
                case "happy":
                    indexChoice = rng.Next(0, happyEndings.Count);
                    return happyEndings[indexChoice];

                // Return tragic ending
                case "tragic":
                    indexChoice = rng.Next(0, tragicEndings.Count);
                    return tragicEndings[indexChoice];

                // Return romantic ending
                case "romantic":
                    indexChoice = rng.Next(0, romanticEndings.Count);
                    return romanticEndings[indexChoice];

                // Return funny ending
                case "funny":
                    indexChoice = rng.Next(0, funnyEndings.Count);
                    return funnyEndings[indexChoice];

                // Return twist ending
                case "twist":
                    indexChoice = rng.Next(0, twistEndings.Count);
                    return twistEndings[indexChoice];

                // Return any ending
                case "any":
                    indexChoice = rng.Next(0, listConflicts.Count);
                    return listConflicts[indexChoice];

                // Default, should be unreachable
                default:
                    return "No conflict detected";
            }

        }
    }
}
