    using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{

    public Slider healthSlider;

    /// <summary>
    /// sets the health sliders max health as well as setting the health to that value
    /// </summary>
    /// <param name="health"></param>
    public void SetMaxHealth(int health)
    {
        healthSlider.maxValue = health;
        healthSlider.value = health;
    }

    /// <summary>
    /// sets health sliders min health and sets health to the maximum
    /// </summary>
    /// <param name="health"></param>
    public void SetMinHealth(int health)
    {
        healthSlider.minValue = health;
    }

    /// <summary>
    /// sets health slider to the specified health value
    /// </summary>
    /// <param name="health"></param>
    public void SetHealth(int health)
    {
        healthSlider.value = health;
    }
}
