using System.Collections;
using System.Collections.Generic;
using UnityEngine;

abstract class AbstractWeapon : MonoBehaviour
{
    [SerializeField] Rigidbody2D mouse;
    [SerializeField] Transform gunPivot;
    bool active = false;
    bool equiped = false;

    private void Update()
    {
        if (active) {this.transform.position = ((mouse.position - (Vector2)gunPivot.position)).normalized + (Vector2)gunPivot.position;}
        if (equiped && !active) {} // This is when an ai would control the weapon
    }

    bool EquipWeapon(Rigidbody2D mouse, Transform gunPivot)
    {
        this.mouse = mouse;
        this.gunPivot = gunPivot;
        active = true;
        equiped = true;
        return true;
    }

    void Unequip()
    {
        active = false;
        equiped = false;
    }

    void Deactivate()
    {
        active = false;
    }
}
