using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponMouse : MonoBehaviour
{
    [SerializeField] Rigidbody2D rb;
    [SerializeField] Transform player;

    private void Update()
    {
        this.transform.position = ((rb.position - (Vector2)player.position)).normalized + (Vector2)player.position;
 
    }
}
