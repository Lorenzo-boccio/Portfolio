using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    [SerializeField] Transform interactPoint;
    [SerializeField] float interactRange = 0.5f;
    [SerializeField] LayerMask interactLayer;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            Interact();
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(interactPoint.position, interactRange);
    }

    void Interact()
    {
        Collider2D[] weapons = Physics2D.OverlapCircleAll(interactPoint.position, interactRange, interactLayer);
        // AbstractWeapon closest; // TODO: implement taking the closest weapon in the overap area
        // foreach (Collider2D weapon in weapons)

        if (weapons.Length > 0)
        {
            //weapons[0].EquipWeapon();
        }
    }
}
