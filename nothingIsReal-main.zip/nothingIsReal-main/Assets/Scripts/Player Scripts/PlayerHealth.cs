using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{

    private int maxHealth;
    public int currHealth;

    public int MaxHealth {get; set;}
    public int CurrHealth {get; set;}
    
    public HealthBar healthBar;

    // Start is called before the first frame update
    void Start()
    {
        maxHealth = 10;
        currHealth = 10;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            TakeDamage(10);
        }
        if (Input.GetKeyDown(KeyCode.O))
        {
            HealDamage(10);
        }
    }

    void TakeDamage(int damage)
    {
        currHealth -= damage;
        healthBar.SetHealth(currHealth);
    }

    void HealDamage(int damage)
    {
        currHealth += damage;
        healthBar.SetHealth(currHealth);
    }
}
