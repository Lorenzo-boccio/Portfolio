using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowMouse : MonoBehaviour
{

    Vector3 mousePos;

    Rigidbody2D rb;
    Vector2 pos = new Vector2(0f, 0f);

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        mousePos = Input.mousePosition;
        mousePos = Camera.main.ScreenToWorldPoint(mousePos);
        pos = Vector2.Lerp(transform.position, mousePos, 1);
    }

    void FixedUpdate()
    {
        rb.MovePosition(pos);
    }
}
