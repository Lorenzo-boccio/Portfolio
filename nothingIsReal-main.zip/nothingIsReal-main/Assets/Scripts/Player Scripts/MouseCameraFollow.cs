using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseCameraFollow : MonoBehaviour
{
    // actual rigidbody of object
    Rigidbody2D rb;
    [SerializeField] Rigidbody2D rbPlayer;
    [SerializeField] Rigidbody2D rbMouse;
    int cameraLockX = 4;
    int cameraLockY = 2;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

        void Update()
    {
        rb.position = rbPlayer.position / 2 + rbMouse.position / 2;

        if (rb.position.x > rbPlayer.position.x + cameraLockX)
        {
            rb.position = new Vector2(rbPlayer.position.x + cameraLockX, rb.position.y);
        }
        if (rb.position.x < rbPlayer.position.x - cameraLockX)
        {
            rb.position = new Vector2(rbPlayer.position.x - cameraLockX, rb.position.y);
        }

        if (rb.position.y > rbPlayer.position.y + cameraLockY)
        {
            rb.position = new Vector2(rb.position.x, rbPlayer.position.y + cameraLockY);
        }
        if (rb.position.y < rbPlayer.position.y - cameraLockY)
        {
            rb.position = new Vector2(rb.position.x, rbPlayer.position.y - cameraLockY);
        }
    }
}
