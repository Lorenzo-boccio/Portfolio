using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    //public float smoothSpeed = 0.125f;
    Vector3 offset = new Vector3(0, 0, -10);

    private void LateUpdate()
    {
        //Vector3 endPos = target.position + offset;
        //Vector3 smoothPos = Vector3.Lerp(transform.position, endPos, smoothSpeed);
        //transform.position =  smoothPos;

        transform.position = target.position + offset;   
    }

}
