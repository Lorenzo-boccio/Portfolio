using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlledPlayer : MonoBehaviour
{
    [SerializeField] GameObject[] equipedPlayers = new GameObject[2];
    int activePlayer = 0;

    public float moveSpeed = 5f;

    public Rigidbody2D rb;
    public Animator animator;

    Vector2 movement;
    Vector3 mousePosition;
    Vector3 mouseWorldPosition;

    // Update is called once per frame
    void Update()
    {
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");
        
        mousePosition = Input.mousePosition;
        mousePosition.z = Camera.main.nearClipPlane;
        mouseWorldPosition = Camera.main.ScreenToWorldPoint(mousePosition);

        if (mouseWorldPosition.x > rb.position.x) {
            animator.SetFloat("mouseRight", 1);
        } else {
            animator.SetFloat("mouseRight", -1);
        }

        animator.SetFloat("Horizontal", movement.x);
        animator.SetFloat("Vertical", movement.y);
        animator.SetFloat("Speed", movement.sqrMagnitude);
    }
}
